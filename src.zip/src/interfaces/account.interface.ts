interface OTP {
  email: string;
  otp: string;
}

export { OTP };
