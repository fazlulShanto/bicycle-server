interface SessionData {
	expiresAt: number;
	userEmail: string;
}

export { SessionData };
